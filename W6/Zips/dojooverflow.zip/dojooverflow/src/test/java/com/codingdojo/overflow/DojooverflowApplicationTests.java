package com.codingdojo.overflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojooverflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
