package com.codingdojo.Gold;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoldApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoldApplication.class, args);
	}

}
