package com.codingdojo.Gold;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoldApplicationTests {

	@Test
	void contextLoads() {
	}

}
