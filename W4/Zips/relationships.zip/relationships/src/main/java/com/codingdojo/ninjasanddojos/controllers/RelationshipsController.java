package com.codingdojo.ninjasanddojos.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.codingdojo.ninjasanddojos.models.Dojo;
import com.codingdojo.ninjasanddojos.models.Ninja;
import com.codingdojo.ninjasanddojos.services.DojoServ;
import com.codingdojo.ninjasanddojos.services.NinjaServ;

@Controller
public class RelationshipsController {

	@Autowired DojoServ dojoServ;
	@Autowired NinjaServ ninjaServ;
	
	@GetMapping("/")
	public String index(@ModelAttribute("dojo") Dojo dojo,
			Model model) {
		List<Dojo> dojos = dojoServ.allDojos();
		model.addAttribute("dojos", dojos);
		return "index.jsp";
	}
	
	@PostMapping("/")
	public String create(@Valid @ModelAttribute("dojo") Dojo dojo,
			BindingResult result,
			Model model) {
		if(result.hasErrors()) {
			List<Dojo> dojos = dojoServ.allDojos();
			model.addAttribute("dojos", dojos);
			return "index.jsp";
		} 
		dojoServ.createDojo(dojo);
		return "redirect:/";
	}
	
	@GetMapping("/dojo/new/ninja")
	public String newNinja(@ModelAttribute("ninja") Ninja ninja,
			Model model) {
		List<Dojo> dojos = dojoServ.allDojos();
		model.addAttribute("dojos", dojos);
		return "ninja.jsp";
	}
	
	@PostMapping("/dojo/new/ninja")
	public String addNinja(@Valid @ModelAttribute("ninja") Ninja ninja,
			BindingResult result,
			Model model) {
		if(result.hasErrors()) {
			List<Dojo> dojos = dojoServ.allDojos();
			model.addAttribute("dojos", dojos);
			return "ninja.jsp";
		}
		ninjaServ.createNinja(ninja);
		return "redirect:/";
	}
	
	@GetMapping("/dojo/ninjas/{id}")
	public String dojoNinjas(
			@PathVariable("id") Long id,
			Model model) {
		List<Ninja> ninjas = ninjaServ.dojoNinjas(id);
		Dojo theDojo = dojoServ.singleDojo(id);
		model.addAttribute("dojo", theDojo);
		model.addAttribute("ninjas", ninjas);
		return "dojo.jsp";
	}
	
	@DeleteMapping("/dojo/delete/{id}")
	public String deleteDojo(@PathVariable("id") Long id) {
		dojoServ.deleteDojo(id);
		return "redirect:/";
	}
	
}
