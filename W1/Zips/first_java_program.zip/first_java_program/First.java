public class First {
    public static void main(String[] args) {
        System.out.println("Bobby Nemeth");
        System.out.println("31");
        System.out.println("Polson, MT");
    }
}