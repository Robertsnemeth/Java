package order_and_items;

public class Item {
	public String name;
	public double price;

}
