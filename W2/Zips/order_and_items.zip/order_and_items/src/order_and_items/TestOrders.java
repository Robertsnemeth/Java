package order_and_items;

public class TestOrders {

	public static void main(String[] args) {
		Item drink1 = new Item();
		Item drink2 = new Item();
		Item drink3 = new Item();
		Item drink4 = new Item();
		
		drink1.price = 3.50;
		drink2.price = 4.50;
		drink3.price = 2.50;
		drink4.price = 5.50;
		
		drink1.name = "mocha";
		drink2.name = "latte";
		drink3.name = "drip coffee";
		drink4.name = "capuccino";
		
		System.out.println(drink1.price);
		
		Order order1 = new Order();
		Order order2 = new Order();
		Order order3 = new Order();
		Order order4 = new Order();
		
		order1.name = "Cindhuri";
		order2.name = "Jimmy";
		order3.name = "Noah";
		order4.name = "Sam";
		
		order2.items.add(drink1);
		order3.items.add(drink4);
		for(int i = 1; i <=3; i++) {
			order4.items.add(drink2);
			}

		for(Item cost : order2.items) {
			order2.total += cost.price;
		}
		
		for(Item cost : order3.items) {
			order3.total += cost.price;
		}
		
		for(Item cost : order4.items) {
			order4.total += cost.price;
		}
		
		order1.ready = true;
		order2.ready = true;
		
		for(int i = 0; i < order4.items.size(); i++) {
			Item d = order4.items.get(i);
			String s = String.valueOf(d);
			System.out.println(s);
		}
		
		System.out.println(order4.items);
		System.out.println(order4.total);

		

		
		
		

	}

}
